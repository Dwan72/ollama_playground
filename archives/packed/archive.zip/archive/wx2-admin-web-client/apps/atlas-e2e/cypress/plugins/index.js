// ***********************************************************
// This example plugins/index.js can be used to load plugins
//
// You can change the location of this file or turn off loading
// the plugins file with the 'pluginsFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/plugins-guide
// ***********************************************************

// This function is called when a project is opened or re-opened (e.g. due to
// the project's config changing)

/**
 * @type {Cypress.PluginConfig}
 */

const {
  getBearerTokenWithCreds,
} = require('../../../../tools/workspace-cli/src/modules/sso-test-helper.js');
const clipboardy = require('clipboardy');
const { install, ensureBrowserFlags } = require('@neuralegion/cypress-har-generator');
const { existsSync, readdirSync, rmSync, writeFile } = require('fs');
const deepmerge = require('deepmerge');
const path = require('path');

module.exports = (on, origConfig) => {
  // `on` is used to hook into various events Cypress emits
  // `config` is the resolved Cypress config

  // Check config for a custom `extends` prop and merge original config with extended config.
  // Cypress will automatically re-merge the originally resolved config (origConfig) with this newly returned config (config).
  // - see: https://www.cypress.io/blog/2020/06/18/extending-the-cypress-config-file
  let config;
  const configJson = require(origConfig.configFile);
  if (configJson.extends) {
    const baseConfigFilename = path.join(origConfig.projectRoot, configJson.extends);
    const baseConfig = require(baseConfigFilename);
    console.log(`merging ${baseConfigFilename} with ${origConfig.configFile}`);
    config = deepmerge(baseConfig, configJson);
  } else {
    config = origConfig;
  }

  // In Cypress, environment variables doesn't share the same scope as OS-level environment variables.
  // We pass all `process.env` properties to Cypress environment variables, so that we can access those variables globally in Cypress using `Cypress.env()`.
  // - see: https://docs.cypress.io/guides/guides/environment-variables, https://docs.cypress.io/api/cypress-api/env
  config.env = Object.assign({}, process.env, config.env);

  install(on, config);
  // eslint-disable-next-line default-param-last
  on('before:browser:launch', (browser = {}, launchOptions) => {
    if (browser.family === 'chromium' && browser.name !== 'electron') {
      launchOptions.args.push('--disable-dev-shm-usage');
    }
    ensureBrowserFlags(browser, launchOptions);
    return launchOptions;
  });

  on('task', {
    failed: require('cypress-failed-log/src/failed')(),

    getBearerTokenApi(creds) {
      const { productionBackend, federation = config.env.bsftGeoRegion || 'us' } = config.env;
      return getBearerTokenWithCreds(creds, { productionBackend, federation });
    },

    getBearerTokenApiWithOverride({ creds, configOverride }) {
      if (configOverride) {
        config = deepmerge(config, configOverride);
      }
      const { productionBackend, federation = config.env.bsftGeoRegion || 'us' } = config.env;
      return getBearerTokenWithCreds(creds, { productionBackend, federation });
    },

    log(message) {
      console.log(message);
      return null;
    },

    getClipboard() {
      return clipboardy.readSync();
    },

    writeToClipboard(text) {
      clipboardy.writeSync(text);
      return text;
    },
  });

  on('task', {
    downloads: (downloadspath) => {
      return readdirSync(downloadspath);
    },
  });

  on('task', {
    csvToJson(data) {
      let lines = data.split('\n');
      let result = [];
      let headers = lines[0].split(',');
      for (let i = 1; i < lines.length; i += 1) {
        let obj = {};
        let currentline = lines[i].split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        for (let j = 0; j < headers.length; j += 1) {
          obj[headers[j]] =
            currentline[j] && currentline[j] !== undefined
              ? currentline[j].replace(/["']/g, '')
              : '';
        }
        result.push(obj);
      }
      return result;
    },
  });
  on('task', {
    finalCsv({ json, updatedCsvFileName }) {
      let fields = Object.keys(json[0]);
      let replacer = (key, value) => {
        return value === null ? '' : value;
      };
      let csv = json.map((row) => {
        return fields
          .map((fieldName) => {
            return JSON.stringify(row[fieldName], replacer);
          })
          .join(',');
      });
      csv.unshift(fields.join(','));
      csv = csv.join('\r\n');
      writeFile('cypress/downloads/' + updatedCsvFileName, csv);
      return csv;
    },
  });
  on('task', {
    updateCsvData({ csvData, finalJsonArray }) {
      if (finalJsonArray.length > 0) {
        finalJsonArray.splice(0, 1);
      }
      finalJsonArray.push(csvData);
      return finalJsonArray;
    },
  });
  on('task', {
    readFiles: async (folderPath) => {
      const files = readdirSync(folderPath);
      return files.filter((file) => file.startsWith('TestRetryMetrics') && file.endsWith('.json'));
    },
    readFile: async ({ filePath }) => {
      const jsonData = require(filePath);
      return JSON.stringify(jsonData);
    },
    fileExists: async (folderPath) => {
      return existsSync(folderPath);
    },
  });

  if (!config.videoUploadOnPasses) {
    // With this option `false`, passing tests do not compress (or upload, but not relevant to us) videos, but they still exist.
    // Delete passing spec videos so they are not archived as results from the workspace.
    // - see: https://docs.cypress.io/guides/guides/screenshots-and-videos#Only-upload-videos-for-specs-with-failing-or-retried-tests
    on('after:spec', (_spec, results) => {
      if (results?.video) {
        const failures = (results?.tests ?? []).some((test) => {
          return test.attempts.some((attempt) => {
            return attempt.state === 'failed';
          });
        });
        if (!failures && existsSync(results.video)) {
          rmSync(results.video);
        }
      }
    });
  }

  return config;
};
